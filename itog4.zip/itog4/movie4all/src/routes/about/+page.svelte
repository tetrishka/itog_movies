<svelte:head>
	<title>О нас</title>
	<meta name="description" content="About this app" />
</svelte:head>

<div class="text-column">
	<h1>Movie4all</h1>

	<p>
		Всё, для Вашего счастья!
	</p>

</div>