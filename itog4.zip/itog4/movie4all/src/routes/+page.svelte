<script>
	import Counter from './Counter.svelte';
	import welcome from '$lib/images/svelte-welcome.webp';
	import welcome_fallback from '$lib/images/svelte-welcome.png';
</script>

<svelte:head>
	<title>Главная</title>
	<meta name="description" content="Svelte demo app" />

	<style>
        .slot {
            background-color: white;
            box-shadow: 0 2px 7px rgba(0, 0, 0, 0.15);
            border-radius: 30px;
            padding: 30px;
            margin: 14px 0;
        }
		.slot:hover {
			outline: solid;
			outline-width: 5px;
			outline-color: #FF2B2B;
		}
		.image {
  		width: 15%;
		min-width: 120px;
  		height: 15%;
		border-radius: 15px;
		background: url(<path-to-image>), lightgray 50% / cover no-repeat;
		margin-right: 2%;
		float: left;
	}
        #addButton {
			--color-text: rgba(0, 0, 0);
            all: unset;
            background: #FF2B2B;
            border: none;
            cursor: pointer;
            border-radius: 15px;
            text-align: center;
            font-size: 24px;
            padding: 10px 24px;
            display: block;
            margin: auto;
			box-shadow: 0 2px 7px rgba(0, 0, 0, 0.15);
            transition: all 0.2s linear;
        }
        #addButton:hover {
            color: var(--color-theme-1);
        }
    </style>

</svelte:head>

<section>
	<h1>Программа на сегодня</h1>

	<div class="container">
        <button id="addButton">Отобразить</button>
        <div id="List"></div>
    </div>

	<script src="https://cdn.jsdelivr.net/npm/mustache@4.2.0/mustache.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            let variants = [{
                    title: 'Твоё имя',
					year: 2016,
					description: 'Токийский парень Таки и провинциальная девушка Мицуха обнаруживают, что между ними существует странная связь. Во сне они меняются телами и проживают жизни друг друга. Но однажды эта способность исчезает так же внезапно, как появилась. Таки решает во что бы то ни стало отыскать Мицуху.',
					image: 'https://www.kinopoisk.ru/E3M04p322/f9f718Gwq/5mz657Nm2ZidSX7vZDnDCfl183dVGFi9EtkNs9DO-CE6gsoiATXts-HRVv0HyhrWMq_XA3PscI0bLbME_tlAS9dlu9euGpyorVwGlwVh7kXhDNNWDCgxnEvJef6lo4Sd-iICh8mtERNhYNPkPsZ7q0Py11YumVnFbjn2zWa95VZ2fD4_X6K8iJHxdxPkgUe1JZwv91kZtP2KXJVPIHrgAZKOqlNpWWVXKRAnsN4H69O71qvarjVxxDYZagU7_fWahryum49GoPiRUYNrSI1_1a0g_2PVUYT5vpgZVyT6UEECxppTMSXhD0VcU_T2r3szy1L71vo1tVDeXT59Q6mB8jIwKmebYrgw9ZVbR1iVZ0nFyItrmcUAxUYc9Rf8HkCJOmLeI7HFsVO5DGNQhvv_p9eaY4KWOYVMxlnCid-1zZ7qrBYbn46IBGE583ec1U-daRzHl2WB_HkmLFFPxP70VW7Gmju5mfknPfxTdOoTgzOvig9eiq2pjIpdsqVDDXWKZox28-uG1HyhCeOTWIErkY3068vhibCFKlB1t_Au7EnizsbHqdEZ13lgb6wGj3_LK25_RgIRodh2URr9x-GNsobc2v_7ctSQYb07k5BtfylptJfDHWk8aUJMKb9sohCJlqJel1E5UbtJyF8A3j8PO09Cq7a69RGkChX6cVeZEdom6NIXo7oglCGJPxukOXN5sUyHS42ZaBHmsBm_6PpU3WYOFlOxieHTIZzzNFKj60snmn86FpndJG5RhvWDlblK1jBWv4uywCgF3Vv3WA3XKX08Y2NNLWAxNpDxB7R-jPnGwkIr1VF9O_HAc2zSw3_DJ-a3EoYpmaSGyXIpz91Vxs6sLv9vokiwAZlbs2DZT7U9gCMXmZEwyba0ES-8upD52uLaAwWJaafRdKvgItOTT3-S3xIOHYlsNhmmJVf9YbZyKNovAyYArGVxj7eQrUcJZdSHhwmNMDXCUJVLQBbgVaKqFq8BHY3nqZDf4CaP4yvvEkOKHt2FSJb9HlVfIY2-Avwmqwc-JOyVVfP7rIGrcbnYx4vlVVB1ApAxe9g2TDm-am4_IXXF-0lwj5BOD18bz-YDOhapwUiOseqh24l1XlYomgNnhogQnUk_07DZS11FzItXdRUwiQ7MqdNQbkxVspKO2-W9xZPV6AuQJj93K1P2386iZRGoSn2meaeNwQY2ZOrjh_o0GGHt008MucONMQjb83UdeCmeWGn7IG7UoWL-TgPxUXWHndi_LLYrK8N3Bu8GPmn90FKlug2r6ZEC3hBSey_yRPD1kWf_NKmbCVWkr8tpQTCprjx1f5D--OW6rhojjcWFu734b6A624Orz_7jAprdXQDivXoZs_UNzkIYbjsPvtQ0CV1bU8A1f63lEINHqe3cdUq0nReU4uitouKWX6WN0SPZUFu0MvvjI-NSe_62IcXYvnVmGUf9YcJKFCYHM2Is8K0xP48E3efFvTgT8115gCm6PGGLlDKk7Tr-Uk9RBeV_rVhjkE4HExN7EvtCAo3NSOrN_nW3rZUCzgxqEyvmyBxxZYcPyJFnXU18W1cd2VQN7txhI8x-jLmOwkIXnQ3Rv7FsSxy2w1ubr_73flYVdXg26eK5353pQqYExu9z9ojoGQV7m8zpL3nZzKOTVXVcFYqcAVfg8gAFMj4eP4mJPf_1AGf4zocfw99mty5OWVH0cuFKLR-5iUr2BF4XizI8OOFt0x_ItZtZCfAbc3GV1I2ikAmntBZI9TaO7tflBXWzmehHCHqXqxt_zss-Ci0F_H41coWXWRkG3iQ2-wdmxBTNyaN_2HEj1U0M-xMpnaz1VrxZKzRCjK1uOkaD4cF5L3EQuzy633ePJ2ozOtotnTTCwW41U2kV9i7wvr93mkjA7YXbf4Tx840pQGfvfe3UOdKorZvInuhpHhKCL_XVzYM9ZG-0co8fW1su88IeaXVUGhEGCacpVX7KuN6Lj7owjAHta2vkfTM1TbTbmykZWK2KJIn3-NqgMaoOlt8RPY2PFQxLPF77W-fT1k8ihvGl0LJhclUXtbkqtqB26_cyDHT9ZRuD0BXjxa2II9sNQQTxVlxZh2D--NmewuZbAXGRp8Ho97T-v1Mvo9ZXrtKR2UyKpSZpe501koJgGgerEgjIBYUb50g5ryVdGBNDWX38aVoUPbecJoT97rJO63Wxiau5bN90_g9Xg3fWM35yedVkmr3C4b-N-UrekN5jb54cuK3Jj2ccDWdZ3TRj013hhPFWSHF3QDIgyaYiru9lJU2DoZzT8Da7p5PXhieeSl1FvJbddr1HIbnWIhCqA58yjCT1QedblCkrNfUYi_shYaQFgkxZ08TKAFWmCj5boXUJnz0cR9gKX3Ojw063LgJxMSQaaRqN_-H5TkJ8emenCrgYGZW3awRZY9HBmEMDCRlgwdLAmSvAtkzlPoa2G5nRESdZcIMYug_fQ2-CU_4aVbHIkrVuUVsZNRIK0MKvu5pItPH52_PY6VMpXUBv06mB4DUSvOnDJJ5osUKuZrOZJRmnZQArFLZP80tDnoMe2olJjMKRipU3sYl20vCe17t6dORBYVtzEGVv_QlEQ4uBEXipApAJ05DqAEVaitJPDUFt-7Hgq9jmgxe_cw5XTiZ1pYyG7Wah2_ExDi542nvj_sBI7Znnf0Shy8lNxINT1dGA6ZogGZNcqnR9NupeN1X5wbOpmH_sOguPr1caK176XUGkvvkaLS8BDYqC7Daf92rIgEEFN-9AdbO5ISST72Xt_J3CxCE_4NZY9Spi0tuxLXm7edC_aOqn65PHGoMeSgUxLA4Zxo0vlZ2-xpBa93NOnHA9vVeL2C07KXEMX1fxaSCBHsh992jqjIUiPt4HoYEd483QO2j2M-u3gypHNhoB2UzuTfJRNynZIvqgNovTSnQA5V3bwzD1L3nFuJNrYWmgrU7oEQvEbvDRxr4mUyXBDevxrONwwk8rTz-ub1pWgT0k5nms'
				},
                {
                    title: 'Форма голоса',
					year: 2016,
					description: 'Молодой человек Сёя Исида внезапно осознаёт, что в школе умудрился превратить жизнь одноклассницы Сёко в ад только потому, что та была глухая. И теперь, хоть и запоздало, парень понимает — чтобы сказать нечто важное тому, кто не может тебя услышать, вовсе не обязательно использовать голос.',
					image: 'https://www.kinopoisk.ru/E3M04p322/f9f718Gwq/5mz657Nm2ZidSX7vZDnDCfl183dVGFi9EtkNs9DO-CE6gsoiATXts-HRVv0D_iLmAq_WdgvgRf0eYa8E07VYW9dlqrLqGpH99BgGlkl58kn9GaoXSVABnEvJef6lo4Sd-iICh8mtERNhYNPkPsZ7q0Py11YumVnFbjn2zWa95VZ2fD4_X6K8iJHxdxPkgUe1JZwv91kZtP2KXJVPIHrgAZKOqlNpWWVXKRAnsN4H69O71qvarjVxxDYZagU7_fWahryum49GoPiRUYNrSI1_1a0g_2PVUYT5vpgZVyT6UEECxppTMSXhD0VcU_T2r3szy1L71vo1tVDeXT59Q6mB8jIwKmebYrgw9ZVbR1iVZ0nFyItrmcUAxUYc9Rf8HkCJOmLeI7HFsVO5DGNQhvv_p9eaY4KWOYVMxlnCid-1zZ7qrBYbn46IBGE583ec1U-daRzHl2WB_HkmLFFPxP70VW7Gmju5mfknPfxTdOoTgzOvig9eiq2pjIpdsqVDDXWKZox28-uG1HyhCeOTWIErkY3068vhibCFKlB1t_Au7EnizsbHqdEZ13lgb6wGj3_LK25_RgIRodh2URr9x-GNsobc2v_7ctSQYb07k5BtfylptJfDHWk8aUJMKb9sohCJlqJel1E5UbtJyF8A3j8PO09Cq7a69RGkChX6cVeZEdom6NIXo7oglCGJPxukOXN5sUyHS42ZaBHmsBm_6PpU3WYOFlOxieHTIZzzNFKj60snmn86FpndJG5RhvWDlblK1jBWv4uywCgF3Vv3WA3XKX08Y2NNLWAxNpDxB7R-jPnGwkIr1VF9O_HAc2zSw3_DJ-a3EoYpmaSGyXIpz91Vxs6sLv9vokiwAZlbs2DZT7U9gCMXmZEwyba0ES-8upD52uLaAwWJaafRdKvgItOTT3-S3xIOHYlsNhmmJVf9YbZyKNovAyYArGVxj7eQrUcJZdSHhwmNMDXCUJVLQBbgVaKqFq8BHY3nqZDf4CaP4yvvEkOKHt2FSJb9HlVfIY2-Avwmqwc-JOyVVfP7rIGrcbnYx4vlVVB1ApAxe9g2TDm-am4_IXXF-0lwj5BOD18bz-YDOhapwUiOseqh24l1XlYomgNnhogQnUk_07DZS11FzItXdRUwiQ7MqdNQbkxVspKO2-W9xZPV6AuQJj93K1P2386iZRGoSn2meaeNwQY2ZOrjh_o0GGHt008MucONMQjb83UdeCmeWGn7IG7UoWL-TgPxUXWHndi_LLYrK8N3Bu8GPmn90FKlug2r6ZEC3hBSey_yRPD1kWf_NKmbCVWkr8tpQTCprjx1f5D--OW6rhojjcWFu734b6A624Orz_7jAprdXQDivXoZs_UNzkIYbjsPvtQ0CV1bU8A1f63lEINHqe3cdUq0nReU4uitouKWX6WN0SPZUFu0MvvjI-NSe_62IcXYvnVmGUf9YcJKFCYHM2Is8K0xP48E3efFvTgT8115gCm6PGGLlDKk7Tr-Uk9RBeV_rVhjkE4HExN7EvtCAo3NSOrN_nW3rZUCzgxqEyvmyBxxZYcPyJFnXU18W1cd2VQN7txhI8x-jLmOwkIXnQ3Rv7FsSxy2w1ubr_73flYVdXg26eK5353pQqYExu9z9ojoGQV7m8zpL3nZzKOTVXVcFYqcAVfg8gAFMj4eP4mJPf_1AGf4zocfw99mty5OWVH0cuFKLR-5iUr2BF4XizI8OOFt0x_ItZtZCfAbc3GV1I2ikAmntBZI9TaO7tflBXWzmehHCHqXqxt_zss-Ci0F_H41coWXWRkG3iQ2-wdmxBTNyaN_2HEj1U0M-xMpnaz1VrxZKzRCjK1uOkaD4cF5L3EQuzy633ePJ2ozOtotnTTCwW41U2kV9i7wvr93mkjA7YXbf4Tx840pQGfvfe3UOdKorZvInuhpHhKCL_XVzYM9ZG-0co8fW1su88IeaXVUGhEGCacpVX7KuN6Lj7owjAHta2vkfTM1TbTbmykZWK2KJIn3-NqgMaoOlt8RPY2PFQxLPF77W-fT1k8ihvGl0LJhclUXtbkqtqB26_cyDHT9ZRuD0BXjxa2II9sNQQTxVlxZh2D--NmewuZbAXGRp8Ho97T-v1Mvo9ZXrtKR2UyKpSZpe501koJgGgerEgjIBYUb50g5ryVdGBNDWX38aVoUPbecJoT97rJO63Wxiau5bN90_g9Xg3fWM35yedVkmr3C4b-N-UrekN5jb54cuK3Jj2ccDWdZ3TRj013hhPFWSHF3QDIgyaYiru9lJU2DoZzT8Da7p5PXhieeSl1FvJbddr1HIbnWIhCqA58yjCT1QedblCkrNfUYi_shYaQFgkxZ08TKAFWmCj5boXUJnz0cR9gKX3Ojw063LgJxMSQaaRqN_-H5TkJ8emenCrgYGZW3awRZY9HBmEMDCRlgwdLAmSvAtkzlPoa2G5nRESdZcIMYug_fQ2-CU_4aVbHIkrVuUVsZNRIK0MKvu5pItPH52_PY6VMpXUBv06mB4DUSvOnDJJ5osUKuZrOZJRmnZQArFLZP80tDnoMe2olJjMKRipU3sYl20vCe17t6dORBYVtzEGVv_QlEQ4uBEXipApAJ05DqAEVaitJPDUFt-7Hgq9jmgxe_cw5XTiZ1pYyG7Wah2_ExDi542nvj_sBI7Znnf0Shy8lNxINT1dGA6ZogGZNcqnR9NupeN1X5wbOpmH_sOguPr1caK176XUGkvvkaLS8BDYqC7Daf92rIgEEFN-9AdbO5ISST72Xt_J3CxCE_4NZY9Spi0tuxLXm7edC_aOqn65PHGoMeSgUxLA4Zxo0vlZ2-xpBa93NOnHA9vVeL2C07KXEMX1fxaSCBHsh992jqjIUiPt4HoYEd483QO2j2M-u3gypHNhoB2UzuTfJRNynZIvqgNovTSnQA5V3bwzD1L3nFuJNrYWmgrU7oEQvEbvDRxr4mUyXBDevxrONwwk8rTz-ub1pWgT0k5nms'
				},
				{
                    title: 'Однажды в Токио',
					year: 2003,
					description: 'Трое бездомных — алкоголик-бродяга Джин, трансвестит Хана и беглая беспризорница Миюки — живут на улицах Токио. Они уже давно позабыли, что значит иметь крышу над головой и есть три раза в день. Им уже ничего не нужно от жизни, и она проходит мимо них. Но однажды в Сочельник наша троица находит на улице потерянную новорожденную девочку, и в опустившихся бродяжках просыпаются забытые было человеческие чувства — приятели решают во что бы то ни стало найти родителей малютки.',
					image: 'https://www.kinopoisk.ru/E3M04p322/f9f718Gwq/5mz657Nm2ZidSX7vZDnDCfl183dVGFi9EtkNs9DO-CE6gsoiATXts-HRVukv2g7eJo_XG3PwXIxOaMMFivQcR9dlrqeuGpCt7AgGsmVcvni4VZtaCAV1nEvJef6lo4Sd-iICh8mtERNhYNPkPsZ7q0Py11YumVnFbjn2zWa95VZ2fD4_X6K8iJHxdxPkgUe1JZwv91kZtP2KXJVPIHrgAZKOqlNpWWVXKRAnsN4H69O71qvarjVxxDYZagU7_fWahryum49GoPiRUYNrSI1_1a0g_2PVUYT5vpgZVyT6UEECxppTMSXhD0VcU_T2r3szy1L71vo1tVDeXT59Q6mB8jIwKmebYrgw9ZVbR1iVZ0nFyItrmcUAxUYc9Rf8HkCJOmLeI7HFsVO5DGNQhvv_p9eaY4KWOYVMxlnCid-1zZ7qrBYbn46IBGE583ec1U-daRzHl2WB_HkmLFFPxP70VW7Gmju5mfknPfxTdOoTgzOvig9eiq2pjIpdsqVDDXWKZox28-uG1HyhCeOTWIErkY3068vhibCFKlB1t_Au7EnizsbHqdEZ13lgb6wGj3_LK25_RgIRodh2URr9x-GNsobc2v_7ctSQYb07k5BtfylptJfDHWk8aUJMKb9sohCJlqJel1E5UbtJyF8A3j8PO09Cq7a69RGkChX6cVeZEdom6NIXo7oglCGJPxukOXN5sUyHS42ZaBHmsBm_6PpU3WYOFlOxieHTIZzzNFKj60snmn86FpndJG5RhvWDlblK1jBWv4uywCgF3Vv3WA3XKX08Y2NNLWAxNpDxB7R-jPnGwkIr1VF9O_HAc2zSw3_DJ-a3EoYpmaSGyXIpz91Vxs6sLv9vokiwAZlbs2DZT7U9gCMXmZEwyba0ES-8upD52uLaAwWJaafRdKvgItOTT3-S3xIOHYlsNhmmJVf9YbZyKNovAyYArGVxj7eQrUcJZdSHhwmNMDXCUJVLQBbgVaKqFq8BHY3nqZDf4CaP4yvvEkOKHt2FSJb9HlVfIY2-Avwmqwc-JOyVVfP7rIGrcbnYx4vlVVB1ApAxe9g2TDm-am4_IXXF-0lwj5BOD18bz-YDOhapwUiOseqh24l1XlYomgNnhogQnUk_07DZS11FzItXdRUwiQ7MqdNQbkxVspKO2-W9xZPV6AuQJj93K1P2386iZRGoSn2meaeNwQY2ZOrjh_o0GGHt008MucONMQjb83UdeCmeWGn7IG7UoWL-TgPxUXWHndi_LLYrK8N3Bu8GPmn90FKlug2r6ZEC3hBSey_yRPD1kWf_NKmbCVWkr8tpQTCprjx1f5D--OW6rhojjcWFu734b6A624Orz_7jAprdXQDivXoZs_UNzkIYbjsPvtQ0CV1bU8A1f63lEINHqe3cdUq0nReU4uitouKWX6WN0SPZUFu0MvvjI-NSe_62IcXYvnVmGUf9YcJKFCYHM2Is8K0xP48E3efFvTgT8115gCm6PGGLlDKk7Tr-Uk9RBeV_rVhjkE4HExN7EvtCAo3NSOrN_nW3rZUCzgxqEyvmyBxxZYcPyJFnXU18W1cd2VQN7txhI8x-jLmOwkIXnQ3Rv7FsSxy2w1ubr_73flYVdXg26eK5353pQqYExu9z9ojoGQV7m8zpL3nZzKOTVXVcFYqcAVfg8gAFMj4eP4mJPf_1AGf4zocfw99mty5OWVH0cuFKLR-5iUr2BF4XizI8OOFt0x_ItZtZCfAbc3GV1I2ikAmntBZI9TaO7tflBXWzmehHCHqXqxt_zss-Ci0F_H41coWXWRkG3iQ2-wdmxBTNyaN_2HEj1U0M-xMpnaz1VrxZKzRCjK1uOkaD4cF5L3EQuzy633ePJ2ozOtotnTTCwW41U2kV9i7wvr93mkjA7YXbf4Tx840pQGfvfe3UOdKorZvInuhpHhKCL_XVzYM9ZG-0co8fW1su88IeaXVUGhEGCacpVX7KuN6Lj7owjAHta2vkfTM1TbTbmykZWK2KJIn3-NqgMaoOlt8RPY2PFQxLPF77W-fT1k8ihvGl0LJhclUXtbkqtqB26_cyDHT9ZRuD0BXjxa2II9sNQQTxVlxZh2D--NmewuZbAXGRp8Ho97T-v1Mvo9ZXrtKR2UyKpSZpe501koJgGgerEgjIBYUb50g5ryVdGBNDWX38aVoUPbecJoT97rJO63Wxiau5bN90_g9Xg3fWM35yedVkmr3C4b-N-UrekN5jb54cuK3Jj2ccDWdZ3TRj013hhPFWSHF3QDIgyaYiru9lJU2DoZzT8Da7p5PXhieeSl1FvJbddr1HIbnWIhCqA58yjCT1QedblCkrNfUYi_shYaQFgkxZ08TKAFWmCj5boXUJnz0cR9gKX3Ojw063LgJxMSQaaRqN_-H5TkJ8emenCrgYGZW3awRZY9HBmEMDCRlgwdLAmSvAtkzlPoa2G5nRESdZcIMYug_fQ2-CU_4aVbHIkrVuUVsZNRIK0MKvu5pItPH52_PY6VMpXUBv06mB4DUSvOnDJJ5osUKuZrOZJRmnZQArFLZP80tDnoMe2olJjMKRipU3sYl20vCe17t6dORBYVtzEGVv_QlEQ4uBEXipApAJ05DqAEVaitJPDUFt-7Hgq9jmgxe_cw5XTiZ1pYyG7Wah2_ExDi542nvj_sBI7Znnf0Shy8lNxINT1dGA6ZogGZNcqnR9NupeN1X5wbOpmH_sOguPr1caK176XUGkvvkaLS8BDYqC7Daf92rIgEEFN-9AdbO5ISST72Xt_J3CxCE_4NZY9Spi0tuxLXm7edC_aOqn65PHGoMeSgUxLA4Zxo0vlZ2-xpBa93NOnHA9vVeL2C07KXEMX1fxaSCBHsh992jqjIUiPt4HoYEd483QO2j2M-u3gypHNhoB2UzuTfJRNynZIvqgNovTSnQA5V3bwzD1L3nFuJNrYWmgrU7oEQvEbvDRxr4mUyXBDevxrONwwk8rTz-ub1pWgT0k5nms'
                },
				{
                    title: 'Актриса тысячелетия',
					year: 2001,
					description: 'Десятилетиями Тиёко Фудзивара была выдающейся актрисой, снимавшейся в фильмах различных жанров. Однажды к ней в высокогорную виллу приезжают продюсер и хроникер, работающий над историей жизни и карьеры Тиёко. Он принес с собой маленький старый ключик, открывший многие тайны ее воспоминаний.',
					image: 'https://www.kinopoisk.ru/E3M04p322/f9f718Gwq/5mz657Nm2ZidSX7vZDnDCfl183dVGFi9EtkNs9DO-CE6gsoiATXts-HRVv0_2hLiNpPWWhv4cL0DOasFi7gUS9dlrrOuGp395BQHxklh8kikVNoDUAwpnEvJef6lo4Sd-iICh8mtERNhYNPkPsZ7q0Py11YumVnFbjn2zWa95VZ2fD4_X6K8iJHxdxPkgUe1JZwv91kZtP2KXJVPIHrgAZKOqlNpWWVXKRAnsN4H69O71qvarjVxxDYZagU7_fWahryum49GoPiRUYNrSI1_1a0g_2PVUYT5vpgZVyT6UEECxppTMSXhD0VcU_T2r3szy1L71vo1tVDeXT59Q6mB8jIwKmebYrgw9ZVbR1iVZ0nFyItrmcUAxUYc9Rf8HkCJOmLeI7HFsVO5DGNQhvv_p9eaY4KWOYVMxlnCid-1zZ7qrBYbn46IBGE583ec1U-daRzHl2WB_HkmLFFPxP70VW7Gmju5mfknPfxTdOoTgzOvig9eiq2pjIpdsqVDDXWKZox28-uG1HyhCeOTWIErkY3068vhibCFKlB1t_Au7EnizsbHqdEZ13lgb6wGj3_LK25_RgIRodh2URr9x-GNsobc2v_7ctSQYb07k5BtfylptJfDHWk8aUJMKb9sohCJlqJel1E5UbtJyF8A3j8PO09Cq7a69RGkChX6cVeZEdom6NIXo7oglCGJPxukOXN5sUyHS42ZaBHmsBm_6PpU3WYOFlOxieHTIZzzNFKj60snmn86FpndJG5RhvWDlblK1jBWv4uywCgF3Vv3WA3XKX08Y2NNLWAxNpDxB7R-jPnGwkIr1VF9O_HAc2zSw3_DJ-a3EoYpmaSGyXIpz91Vxs6sLv9vokiwAZlbs2DZT7U9gCMXmZEwyba0ES-8upD52uLaAwWJaafRdKvgItOTT3-S3xIOHYlsNhmmJVf9YbZyKNovAyYArGVxj7eQrUcJZdSHhwmNMDXCUJVLQBbgVaKqFq8BHY3nqZDf4CaP4yvvEkOKHt2FSJb9HlVfIY2-Avwmqwc-JOyVVfP7rIGrcbnYx4vlVVB1ApAxe9g2TDm-am4_IXXF-0lwj5BOD18bz-YDOhapwUiOseqh24l1XlYomgNnhogQnUk_07DZS11FzItXdRUwiQ7MqdNQbkxVspKO2-W9xZPV6AuQJj93K1P2386iZRGoSn2meaeNwQY2ZOrjh_o0GGHt008MucONMQjb83UdeCmeWGn7IG7UoWL-TgPxUXWHndi_LLYrK8N3Bu8GPmn90FKlug2r6ZEC3hBSey_yRPD1kWf_NKmbCVWkr8tpQTCprjx1f5D--OW6rhojjcWFu734b6A624Orz_7jAprdXQDivXoZs_UNzkIYbjsPvtQ0CV1bU8A1f63lEINHqe3cdUq0nReU4uitouKWX6WN0SPZUFu0MvvjI-NSe_62IcXYvnVmGUf9YcJKFCYHM2Is8K0xP48E3efFvTgT8115gCm6PGGLlDKk7Tr-Uk9RBeV_rVhjkE4HExN7EvtCAo3NSOrN_nW3rZUCzgxqEyvmyBxxZYcPyJFnXU18W1cd2VQN7txhI8x-jLmOwkIXnQ3Rv7FsSxy2w1ubr_73flYVdXg26eK5353pQqYExu9z9ojoGQV7m8zpL3nZzKOTVXVcFYqcAVfg8gAFMj4eP4mJPf_1AGf4zocfw99mty5OWVH0cuFKLR-5iUr2BF4XizI8OOFt0x_ItZtZCfAbc3GV1I2ikAmntBZI9TaO7tflBXWzmehHCHqXqxt_zss-Ci0F_H41coWXWRkG3iQ2-wdmxBTNyaN_2HEj1U0M-xMpnaz1VrxZKzRCjK1uOkaD4cF5L3EQuzy633ePJ2ozOtotnTTCwW41U2kV9i7wvr93mkjA7YXbf4Tx840pQGfvfe3UOdKorZvInuhpHhKCL_XVzYM9ZG-0co8fW1su88IeaXVUGhEGCacpVX7KuN6Lj7owjAHta2vkfTM1TbTbmykZWK2KJIn3-NqgMaoOlt8RPY2PFQxLPF77W-fT1k8ihvGl0LJhclUXtbkqtqB26_cyDHT9ZRuD0BXjxa2II9sNQQTxVlxZh2D--NmewuZbAXGRp8Ho97T-v1Mvo9ZXrtKR2UyKpSZpe501koJgGgerEgjIBYUb50g5ryVdGBNDWX38aVoUPbecJoT97rJO63Wxiau5bN90_g9Xg3fWM35yedVkmr3C4b-N-UrekN5jb54cuK3Jj2ccDWdZ3TRj013hhPFWSHF3QDIgyaYiru9lJU2DoZzT8Da7p5PXhieeSl1FvJbddr1HIbnWIhCqA58yjCT1QedblCkrNfUYi_shYaQFgkxZ08TKAFWmCj5boXUJnz0cR9gKX3Ojw063LgJxMSQaaRqN_-H5TkJ8emenCrgYGZW3awRZY9HBmEMDCRlgwdLAmSvAtkzlPoa2G5nRESdZcIMYug_fQ2-CU_4aVbHIkrVuUVsZNRIK0MKvu5pItPH52_PY6VMpXUBv06mB4DUSvOnDJJ5osUKuZrOZJRmnZQArFLZP80tDnoMe2olJjMKRipU3sYl20vCe17t6dORBYVtzEGVv_QlEQ4uBEXipApAJ05DqAEVaitJPDUFt-7Hgq9jmgxe_cw5XTiZ1pYyG7Wah2_ExDi542nvj_sBI7Znnf0Shy8lNxINT1dGA6ZogGZNcqnR9NupeN1X5wbOpmH_sOguPr1caK176XUGkvvkaLS8BDYqC7Daf92rIgEEFN-9AdbO5ISST72Xt_J3CxCE_4NZY9Spi0tuxLXm7edC_aOqn65PHGoMeSgUxLA4Zxo0vlZ2-xpBa93NOnHA9vVeL2C07KXEMX1fxaSCBHsh992jqjIUiPt4HoYEd483QO2j2M-u3gypHNhoB2UzuTfJRNynZIvqgNovTSnQA5V3bwzD1L3nFuJNrYWmgrU7oEQvEbvDRxr4mUyXBDevxrONwwk8rTz-ub1pWgT0k5nms'
                },
            ];
            let addButton = document.getElementById('addButton');
            let List = document.getElementById('List');
            addButton.addEventListener('click', function() {
                let template = document.getElementById('Template').innerHTML;
                let rendered = Mustache.render(template, {
                    variants: variants
                });
                List.innerHTML = rendered;
            });
        });
    </script>
    <script id="Template" type="x-tmpl-mustache">
        {{#variants}}
            <div class="slot">
				<img src="{{image}}" alt="{{title}}" class="image">
				<h2>{{title}}</h2>
				<p>{{year}}</p>
                <p>{{description}}</p>
            </div>
        {{/variants}}
    </script>
</section>